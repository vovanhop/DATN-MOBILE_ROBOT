#!/usr/bin/env python
import rospy
from std_msgs.msg import Int32MultiArray
from geometry_msgs.msg import Quaternion, Twist
import math
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64

import tf


# lineare maxx : 0.08
# 	min 0.015
# angular z max 0.5
# 	min 0.15
class Node:
    def __init__(self):
        rospy.init_node("robot_firmware")

        rospy.Subscriber("pose_encod",Int32MultiArray,self.pose_encod_cb)
        rospy.Subscriber("delta_enc",Int32MultiArray,self.delta_encod_cb)
        rospy.Subscriber("cmd_vel",Twist,self.cmd_vel_cb)

        self.duty_pub = rospy.Publisher("duty_motor",Int32MultiArray,queue_size=10)
        self.pub_z = rospy.Publisher('/rotate_z', Float64, queue_size=10)
        self.odom_pub = rospy.Publisher('/odom', Odometry, queue_size=10)
        self.odom_broadcaster = tf.TransformBroadcaster()


        self.pose_encod_data = [0,0]
        self.delta_encod_data = [0,0]


        self.last_enc_time = rospy.Time.now()

        self.error_left_now = 0.0 
        self.error_left_last= 0.0
        self.error_left_last_last = 0.0
        self.error_left_all = 0.0
        self.duty_left = 0.0

        self.error_right_now = 0.0 
        self.error_right_last= 0.0
        self.error_right_last_last = 0.0
        self.error_right_all = 0.0
        self.duty_right = 0.0

        self.linear_x = 0.0
        self.angular_z = 0.0
        
        self.distance_wheels = 0.245;
        self.diameter_wheel = 0.065; 

        self.pose_right_old_encod = 0.0;
        self.pose_left_old_encod = 0.0;

        self.pose_right_now_encod = 0.0;
        self.pose_left_now_encod = 0.0;

        self.vel_right_wheel = 0.0
        self.vel_left_wheel = 0.0

        self.position_x = 0.0
        self.position_y = 0.0
        self.angle_z = 0.0

    def cmd_vel_cb(self,msg):
        self.linear_x = msg.linear.x
        self.angular_z = msg.angular.z

        self.vel_right_wheel = ((2 * self.linear_x) + (self.angular_z * self.distance_wheels ))/ 2  # m/s
        self.vel_left_wheel = ((2 * self.linear_x) - (self.angular_z * self.distance_wheels)) / 2 

        
    def pose_encod_cb(self,msg):
        # print(msg)
        self.pose_encod_data = msg.data

    def delta_encod_cb(self,msg):
        self.delta_encod_data  = msg.data
        self.pose_right_now_encod = msg.data[0]
        self.pose_left_now_encod = msg.data[1]

    def run(self):

        r_time = rospy.Rate(10)
        Kp_r =0.1; Ki_r = 0.6 ;Kd_r=0.0
        Kp_l =0.12; Ki_l =0.7; Kd_l=0.0

        vel_right_enc = 0.0
        vel_left_enc = 0.0

        left_pose_encod_new = 0.0
        right_pose_encod_new = 0.0

        while not rospy.is_shutdown():
            

            # print("enc : ", self.pose_encod_data )
            # print("delta : ", self.delta_encod_data )

            
            vel_right_enc = (self.vel_right_wheel/(3.14 * self.diameter_wheel)) * 1848  / 10# 11 xung ecode /s
            vel_left_enc = (self.vel_left_wheel/(3.14 * self.diameter_wheel)) * 1848  / 10

            print("vel_right_wheel:",vel_right_enc)
            print("vel_left_wheel:",vel_left_enc)


            left_pose_encod_new = self.delta_encod_data[1]
            right_pose_encod_new = self.delta_encod_data[0]

            # left_now_encod = self.pose_left_now_encod
            # right_now_encod = self.pose_right_now_encod

            # print("pose_left_now_encod:",pose_left_now_encod)
            # print("pose_right_now_encod:",pose_right_now_encod)

            # left_pose_encod_new = left_now_encod - self.pose_left_old_encod
            # right_pose_encod_new = right_now_encod - self.pose_right_old_encod

            # self.pose_left_old_encod = left_pose_encod_new
            # self.pose_right_old_encod = right_pose_encod_new

            print("right_pose_encod_new:",right_pose_encod_new)
            print("left_pose_encod_new:",left_pose_encod_new)

            D_l= (left_pose_encod_new/1848)*(0.065*3.14)
            D_r= (right_pose_encod_new/1848)*(0.065*3.14)

            current_time = rospy.Time.now()

            d_x = (D_r + D_l) / 2.0
            d_z = (D_r - D_l) / (self.distance_wheels)


            t = (current_time - self.last_enc_time).to_sec()
            print("t  :",t)
            self.last_enc_time = current_time
            rpm_right = right_pose_encod_new / t  # xung treen s
            rpm_left = left_pose_encod_new / t
            
            print("rpm_right:",rpm_right)       # 260 270
            print("rpm_left:",rpm_left)

            linear_x = d_x / t * 10         # Van toc linear thuc te 
            rotate_z = d_z / t   *10      # toc do quay thuc te 
            print( " vels robot : " ,linear_x , rotate_z)
            self.angle_z = self.angle_z + d_z * 10 # Goc Yaw so voi luc dau

            dx =d_x * math.cos(self.angle_z) * 10
            dy=d_x * math.sin(self.angle_z) * 10

            self.position_x = self.position_x + dx   # Toa x so voi luc dau
            self.position_y = self.position_y + dy   # toa do y so voi luc dau
            
            if self.angle_z >= 6.28:
                self.angle_z = self.angle_z - 6.28
            if self.angle_z <= - 6.28:
                self.angle_z = self.angle_z + 6.28


            self.odom_pub_CB(linear_x,rotate_z)
            self.pub_tf_odom(self.position_x,self.position_y, self.angle_z)

            ### PID Left motor
            self.error_left_last_last = self.error_left_last;
            self.error_left_last =  self.error_left_now;
            self.error_left_now = (vel_left_enc -rpm_left );  # Target - reals
            self.error_left_all = self.error_left_all + self.error_left_now;

            P_l = Kp_l *( self.error_left_now);
            I_l = 0.5 *Ki_l *t *(self.error_left_now + self.error_left_last)
            D_l = Kd_l/t * (self.error_left_now - 2*self.error_left_last +self.error_left_last_last);
            
            self.duty_left = self.duty_left + P_l + I_l + D_l

            left = int (abs( self.duty_left))
              
            if (left > 250) : left = 250
            if (left < 0) :left = 0

            print("self.duty_left  :",self.duty_left , self.error_left_now  )


            ### PID Left motor
            self.error_right_last_last = self.error_right_last;
            self.error_right_last =  self.error_right_now;
            self.error_right_now =(vel_right_enc - rpm_right) ;  # Target - reals
            self.error_right_all = self.error_right_all + self.error_right_now;

            P_r = Kp_l *( self.error_right_now);
            I_r = 0.5 *Ki_l *t *(self.error_right_now + self.error_right_last)
            D_r = Kd_l/t * (self.error_right_now - 2*self.error_right_last +self.error_right_last_last);
            
            self.duty_right = self.duty_right + P_r + I_r + D_r
            
            right = int (abs (self.duty_right))


            if (right > 250) : right = 250
            if (right < 0) :right = 0


            if (self.linear_x == 0.0 and self.angular_z == 0.0):
                self.duty_left = 0
                self.duty_right = 0
            print("self.duty_right  :",self.duty_right, self.error_right_now)

            duty_array = Int32MultiArray()
            duty_array.data = [int(right),int(left)]
            # duty_array.data_length = 2 

            self.duty_pub.publish(duty_array)
            # print("t : ",t)
            # print("rpm_right:",rpm_right)
            # print("rpm_left:",rpm_left)
            

            r_time.sleep()

    def odom_pub_CB(self,linear_x,rotate_z):

        odom_quat = Quaternion()
        odom_quat = tf.transformations.quaternion_from_euler(0,0,self.angle_z)
        a = Float64()
        a.data=self.angle_z /3.14 * 180.0
        self.pub_z.publish(a)

        rospy.loginfo(self.angle_z)

        odom_msg = Odometry()
        odom_msg.header.stamp = rospy.Time.now()
        odom_msg.header.frame_id = 'odom'
        odom_msg.child_frame_id = 'base_footprint'

        odom_msg.pose.pose.position.x = self.position_x
        odom_msg.pose.pose.position.y = self.position_y
        odom_msg.pose.pose.position.z = 0.0
        # odom_msg.pose.pose.orientation = odom_quat
        odom_msg.pose.pose.orientation.z = odom_quat[2]
        odom_msg.pose.pose.orientation.w = odom_quat[3]

        odom_msg.pose.covariance[0]= 0.01
        odom_msg.pose.covariance[7]= 0.01
        odom_msg.pose.covariance[14]= 1e-12
        odom_msg.pose.covariance[21]= 1e-12
        odom_msg.pose.covariance[28]= 1e-12
        odom_msg.pose.covariance[35]= 0.01
        
        odom_msg.twist.twist.linear.x = linear_x
        odom_msg.twist.twist.angular.z = rotate_z
        odom_msg.twist.covariance[0]= 0.01
        odom_msg.twist.covariance[7]= 1e-12
        odom_msg.twist.covariance[14]= 1e-12
        odom_msg.twist.covariance[21]= 1e-12
        odom_msg.twist.covariance[28]= 1e-12
        odom_msg.twist.covariance[35]= 0.01

        # print odom_msg
        self.odom_pub.publish(odom_msg)
        
    def pub_tf_odom(self,pose_x,pose_y,rotate_z):
        
        odom_quat = tf.transformations.quaternion_from_euler(0, 0, rotate_z)

        # first, we'll publish the transform over tf
        self.odom_broadcaster.sendTransform(
            (pose_x, pose_y, 0.),
            odom_quat,
            rospy.Time.now(),
            "base_footprint",
            "odom"
        )
if __name__ == "__main__":
    try:
        node = Node()
        node.run()
    except rospy.ROSInterruptException:
        pass
    rospy.loginfo("Exiting")











